import { useState } from "react";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Clock, Send, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";
import { useToast } from "@/hooks/use-toast";

const contactInfo = [
  { icon: Phone, label: "Telefoon", value: "+32 470 12 34 56", href: "tel:+32470123456" },
  { icon: Mail, label: "E-mail", value: "info@voltix.be", href: "mailto:info@voltix.be" },
  { icon: MapPin, label: "Adres", value: "Industrieweg 42, 2000 Antwerpen" },
  { icon: Clock, label: "Openingstijden", value: "Ma-Vr: 8:00 – 18:00" },
  { icon: Phone, label: "24/7 Noodnummer", value: "+32 470 99 88 77", href: "tel:+32470998877" },
];

const Contact = () => {
  const { toast } = useToast();
  const [form, setForm] = useState({ naam: "", email: "", telefoon: "", bericht: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({ title: "Bericht verzonden!", description: "Wij nemen binnen 24 uur contact met u op." });
    setForm({ naam: "", email: "", telefoon: "", bericht: "" });
  };

  return (
    <main>
      <Navbar />

      {/* Header */}
      <section className="pt-32 pb-16 bg-navy">
        <div className="container-max px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
            <span className="text-electric text-sm font-semibold uppercase tracking-widest">Contact</span>
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-primary-foreground mt-2">
              Neem <span className="text-gradient">contact</span> op
            </h1>
            <p className="text-primary-foreground/60 mt-4 max-w-lg mx-auto">
              Vraag een gratis offerte aan of stel uw vraag. Wij reageren binnen 24 uur.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section-padding bg-background">
        <div className="container-max">
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 }}
              className="lg:col-span-3"
            >
              <div className="glass-card p-8">
                <h2 className="font-heading font-bold text-xl text-foreground mb-6">Stuur ons een bericht</h2>
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Naam *</label>
                      <Input
                        required
                        value={form.naam}
                        onChange={(e) => setForm({ ...form, naam: e.target.value })}
                        placeholder="Uw volledige naam"
                        maxLength={100}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-foreground mb-1.5 block">Telefoon</label>
                      <Input
                        value={form.telefoon}
                        onChange={(e) => setForm({ ...form, telefoon: e.target.value })}
                        placeholder="+32 ..."
                        maxLength={20}
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">E-mail *</label>
                    <Input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="uw@email.be"
                      maxLength={255}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium text-foreground mb-1.5 block">Bericht *</label>
                    <Textarea
                      required
                      value={form.bericht}
                      onChange={(e) => setForm({ ...form, bericht: e.target.value })}
                      placeholder="Beschrijf uw project of vraag..."
                      rows={5}
                      maxLength={1000}
                    />
                  </div>
                  <Button type="submit" size="lg" className="w-full bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold hover:opacity-90 transition-opacity">
                    <Send className="w-4 h-4 mr-2" />
                    Verstuur Bericht
                  </Button>
                </form>
              </div>
            </motion.div>

            {/* Info */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.3 }}
              className="lg:col-span-2 space-y-4"
            >
              {contactInfo.map((c) => (
                <div key={c.label} className="glass-card p-5 flex gap-4 items-start">
                  <div className="w-10 h-10 shrink-0 rounded-lg bg-electric/10 flex items-center justify-center">
                    <c.icon className="w-5 h-5 text-electric" />
                  </div>
                  <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider">{c.label}</div>
                    {c.href ? (
                      <a href={c.href} className="text-sm font-semibold text-foreground hover:text-electric transition-colors">{c.value}</a>
                    ) : (
                      <div className="text-sm font-semibold text-foreground">{c.value}</div>
                    )}
                  </div>
                </div>
              ))}

              <a
                href="https://wa.me/32470123456"
                target="_blank"
                rel="noopener noreferrer"
                className="glass-card p-5 flex gap-4 items-center bg-[#25D366]/5 border-[#25D366]/20 hover-lift block"
              >
                <div className="w-10 h-10 shrink-0 rounded-lg bg-[#25D366]/10 flex items-center justify-center">
                  <MessageCircle className="w-5 h-5 text-[#25D366]" />
                </div>
                <div>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider">WhatsApp</div>
                  <div className="text-sm font-semibold text-foreground">Chat direct met ons</div>
                </div>
              </a>

              {/* Map placeholder */}
              <div className="glass-card overflow-hidden">
                <iframe
                  title="Voltix locatie"
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d159743.1723093264!2d4.2462644!3d51.2194475!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47c3f68ebdad7e8f%3A0x6c8e23e0ed4adef8!2sAntwerpen!5e0!3m2!1snl!2sbe!4v1700000000000"
                  width="100%"
                  height="200"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
      <FloatingCTA />
    </main>
  );
};

export default Contact;
