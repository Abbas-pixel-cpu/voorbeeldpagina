import { useState } from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import {
  Zap, Sun, Car, Cpu, Settings, Phone, ArrowRight,
  CheckCircle, ChevronDown, ChevronUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";
import CTASection from "@/components/CTASection";
import electricalImg from "@/assets/electrical-install.jpg";
import solarImg from "@/assets/solar-panels.jpg";
import evImg from "@/assets/ev-charger.jpg";
import domoticaImg from "@/assets/domotica.jpg";
import groepenkastImg from "@/assets/groepenkast.jpg";
import wiringImg from "@/assets/wiring-closeup.jpg";

const services = [
  {
    id: "elektrische-installaties",
    icon: Zap,
    title: "Elektrische Installaties",
    img: electricalImg,
    problem: "Een verouderde of slecht aangelegde elektrische installatie vormt een veiligheidsrisico en voldoet niet aan de huidige AREI-normen.",
    solution: "Voltix installeert volledige nieuwbouw- en renovatie-installaties die 100% conform zijn met de Belgische regelgeving.",
    benefits: ["AREI-conform opgeleverd", "Keuringsklaar bij eerste keuring", "Premium materialen", "10 jaar garantie op installatie", "Strakke en nette afwerking"],
    steps: ["Gratis plaatsbezoek en advies", "Gedetailleerde offerte op maat", "Professionele installatie", "Keuring en oplevering"],
    faqs: [
      { q: "Hoe lang duurt een volledige installatie?", a: "Dit hangt af van de grootte van het project. Een gemiddelde woning duurt 3-5 werkdagen." },
      { q: "Regelen jullie ook de keuring?", a: "Ja, wij plannen de keuring in en zorgen dat alles in orde is voor de eerste doorgang." },
    ],
  },
  {
    id: "zonnepanelen",
    icon: Sun,
    title: "Zonnepanelen",
    img: solarImg,
    problem: "Stijgende energiekosten drukken op uw budget. Fossiele brandstoffen zijn niet duurzaam en uw energierekening blijft maar stijgen.",
    solution: "Met premium zonnepanelen van Voltix bespaart u tot 70% op uw energiekosten en draagt u bij aan een duurzamere toekomst.",
    benefits: ["Tot 70% besparing op energiekosten", "Premium Tier 1 panelen", "Monitoring app inbegrepen", "Terugverdientijd berekening", "Batterijopslag mogelijk"],
    steps: ["Dakanalyse en rendementsstudie", "Offerte met terugverdientijd", "Installatie in 1-2 dagen", "Aansluiting en monitoring"],
    faqs: [
      { q: "Hoeveel panelen heb ik nodig?", a: "Gemiddeld 10-16 panelen voor een gezin. Wij maken een berekening op maat op basis van uw verbruik." },
      { q: "Is er nog subsidie mogelijk?", a: "Ja, wij informeren u over de actuele premies en helpen bij de aanvraag." },
    ],
  },
  {
    id: "laadpalen",
    icon: Car,
    title: "Laadpalen",
    img: evImg,
    problem: "Steeds meer Belgen rijden elektrisch, maar thuis laden is niet altijd evident zonder een professioneel geïnstalleerde laadpaal.",
    solution: "Voltix plaatst slimme laadoplossingen voor thuis en op kantoor, afgestemd op uw elektrische installatie en verbruik.",
    benefits: ["Alle merken en types", "Slim laden met app-bediening", "Subsidie-advies inbegrepen", "Toekomstbestendig", "Load balancing voor meerdere punten"],
    steps: ["Analyse van uw installatie", "Advies over het juiste type", "Professionele installatie", "Configuratie en instructie"],
    faqs: [
      { q: "Kan mijn huidige installatie een laadpaal aan?", a: "Wij controleren dit bij het plaatsbezoek en adviseren of een upgrade nodig is." },
      { q: "Hoe snel laadt mijn auto thuis?", a: "Met een 11kW laadpaal laadt u gemiddeld 50-60 km range per uur bij." },
    ],
  },
  {
    id: "domotica",
    icon: Cpu,
    title: "Domotica",
    img: domoticaImg,
    problem: "Handmatig schakelen van verlichting, verwarming en beveiliging is niet efficiënt en mist comfort in de moderne woning.",
    solution: "Met domotica van Voltix maakt u uw woning intelligent. Alles op één platform, bedienbaar via uw smartphone.",
    benefits: ["KNX, Loxone & meer", "Volledig op maat", "Energiebesparing tot 30%", "Toekomstbestendig systeem", "Professionele programmering"],
    steps: ["Wensen en behoeften inventariseren", "Systeem ontwerpen", "Installatie en programmering", "Training en overdracht"],
    faqs: [
      { q: "Kan domotica ook in een bestaande woning?", a: "Ja, draadloze systemen zoals Loxone Air zijn perfect voor renovatie." },
      { q: "Kan ik het systeem zelf uitbreiden?", a: "Ja, we kiezen systemen die u zelf kunt aanpassen en uitbreiden." },
    ],
  },
  {
    id: "groepenkast-renovaties",
    icon: Settings,
    title: "Groepenkast Renovaties",
    img: groepenkastImg,
    problem: "Een verouderde groepenkast met oude zekeringen vormt een brandgevaar en voldoet niet meer aan de huidige veiligheidsnormen.",
    solution: "Voltix vervangt uw oude groepenkast door een moderne versie met differentieel- en automatische zekeringen.",
    benefits: ["Veiliger wonen", "AREI-conform", "Snelle uitvoering (1 dag)", "Overspanningsbeveiliging", "Nette afwerking"],
    steps: ["Inspectie huidige installatie", "Offerte met duidelijke scope", "Vervanging in één werkdag", "Keuring en certificaat"],
    faqs: [
      { q: "Hoe weet ik of mijn groepenkast verouderd is?", a: "Als u nog smeltzekeringen heeft of als uw installatie ouder is dan 25 jaar, is vervanging aangeraden." },
      { q: "Hoe lang duurt de vervanging?", a: "Een standaard groepenkast vervanging is klaar in één werkdag." },
    ],
  },
  {
    id: "storingsdienst",
    icon: Phone,
    title: "24/7 Storingsdienst",
    img: wiringImg,
    problem: "Een elektrisch defect wacht niet tot kantooruren. Kortsluiting, stroomuitval of rookontwikkeling vereisen onmiddellijke actie.",
    solution: "Ons storingsteam is 24 uur per dag, 7 dagen per week bereikbaar voor urgente elektrische problemen in heel België.",
    benefits: ["24/7 beschikbaar", "Snelle responstijd", "Heel België", "Transparante tarieven", "Ervaren storingsteam"],
    steps: ["Bel ons noodnummer", "Situatie inschatten op afstand", "Technieker ter plaatse", "Probleem veilig opgelost"],
    faqs: [
      { q: "Hoe snel zijn jullie ter plaatse?", a: "Binnen 1-2 uur in de meeste regio's. In urgente gevallen streven we naar minder dan 1 uur." },
      { q: "Wat kost een noodinterventie?", a: "U ontvangt altijd eerst een duidelijke prijsindicatie voordat we starten." },
    ],
  },
];

const FAQItem = ({ q, a }: { q: string; a: string }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-border last:border-0">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between py-4 text-left">
        <span className="font-medium text-foreground text-sm">{q}</span>
        {open ? <ChevronUp className="w-4 h-4 text-electric shrink-0" /> : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />}
      </button>
      {open && <p className="text-sm text-muted-foreground pb-4">{a}</p>}
    </div>
  );
};

const Diensten = () => (
  <main>
    <Navbar />

    <section className="pt-32 pb-16 bg-navy">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <span className="text-electric text-sm font-semibold uppercase tracking-widest">Onze Diensten</span>
          <h1 className="text-4xl md:text-5xl font-heading font-bold text-primary-foreground mt-2">
            Expertise in elke <span className="text-gradient">schakel</span>
          </h1>
          <p className="text-primary-foreground/60 mt-4 max-w-lg mx-auto">
            Van basisinstallatie tot geavanceerde domotica — ontdek ons volledig aanbod.
          </p>
        </motion.div>
      </div>
    </section>

    <section className="section-padding bg-background">
      <div className="container-max space-y-24">
        {services.map((s, idx) => (
          <motion.div
            key={s.id}
            id={s.id}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="scroll-mt-24"
          >
            <div className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-start ${idx % 2 === 1 ? "lg:flex-row-reverse" : ""}`}>
              <div className={idx % 2 === 1 ? "lg:order-2" : ""}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 rounded-lg bg-electric flex items-center justify-center">
                    <s.icon className="w-5 h-5 text-accent-foreground" />
                  </div>
                  <h2 className="text-2xl font-heading font-bold text-foreground">{s.title}</h2>
                </div>

                <div className="glass-card p-5 mb-4 border-l-4 border-l-destructive/50">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-destructive mb-1">Het probleem</h4>
                  <p className="text-sm text-muted-foreground">{s.problem}</p>
                </div>

                <div className="glass-card p-5 mb-6 border-l-4 border-l-electric">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-electric mb-1">Onze oplossing</h4>
                  <p className="text-sm text-muted-foreground">{s.solution}</p>
                </div>

                <h4 className="text-sm font-heading font-semibold text-foreground mb-3">Voordelen</h4>
                <ul className="space-y-2 mb-6">
                  {s.benefits.map((b) => (
                    <li key={b} className="flex items-center gap-2 text-sm text-muted-foreground">
                      <CheckCircle className="w-4 h-4 text-electric shrink-0" />
                      {b}
                    </li>
                  ))}
                </ul>

                <Link to="/contact">
                  <Button className="bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold hover:opacity-90 transition-opacity">
                    Vraag Offerte Aan <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </Link>
              </div>

              <div className={idx % 2 === 1 ? "lg:order-1" : ""}>
                <img src={s.img} alt={s.title} className="rounded-xl shadow-xl w-full mb-6" />

                {/* Steps */}
                <div className="glass-card p-6 mb-6">
                  <h4 className="text-sm font-heading font-semibold text-foreground mb-4">Ons 4-stappen proces</h4>
                  <div className="space-y-3">
                    {s.steps.map((step, i) => (
                      <div key={step} className="flex items-center gap-3">
                        <div className="w-8 h-8 shrink-0 rounded-full bg-electric text-accent-foreground flex items-center justify-center text-xs font-bold">
                          {i + 1}
                        </div>
                        <span className="text-sm text-foreground">{step}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* FAQ */}
                <div className="glass-card p-6">
                  <h4 className="text-sm font-heading font-semibold text-foreground mb-3">Veelgestelde vragen</h4>
                  {s.faqs.map((faq) => (
                    <FAQItem key={faq.q} q={faq.q} a={faq.a} />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>

    <CTASection />
    <Footer />
    <FloatingCTA />
  </main>
);

export default Diensten;
