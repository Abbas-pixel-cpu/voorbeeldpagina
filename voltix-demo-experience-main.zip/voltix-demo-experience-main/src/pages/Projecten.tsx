import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MapPin, ArrowRight, Filter } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";
import CTASection from "@/components/CTASection";
import solarImg from "@/assets/solar-panels.jpg";
import evImg from "@/assets/ev-charger.jpg";
import domoticaImg from "@/assets/domotica.jpg";
import groepenkastImg from "@/assets/groepenkast.jpg";
import electricalImg from "@/assets/electrical-install.jpg";
import wiringImg from "@/assets/wiring-closeup.jpg";

const categories = ["Alle", "Elektrisch", "Zonnepanelen", "Laadpalen", "Domotica", "Groepenkast"];

const projects = [
  {
    img: solarImg,
    title: "Villa Zonnekracht",
    location: "Antwerpen",
    category: "Zonnepanelen",
    challenge: "Groot energieverbruik door warmtepomp en elektrische wagen. De klant zocht maximale zelfvoorziening.",
    approach: "22 premium zonnepanelen met 10kWh batterijopslag en slimme monitoring.",
    result: "75% energiebesparing en volledige onafhankelijkheid overdag. Terugverdientijd: 5 jaar.",
  },
  {
    img: evImg,
    title: "Kantoorpark Laadplein",
    location: "Gent",
    category: "Laadpalen",
    challenge: "Bedrijvenpark met 8 huurders had nood aan gedeelde laadinfrastructuur zonder netverzwaring.",
    approach: "8 slimme 22kW laadpalen met dynamische load balancing en individuele facturatie per huurder.",
    result: "Alle huurders laden nu probleemloos. Het park trekt nu extra bedrijven aan dankzij de laadinfrastructuur.",
  },
  {
    img: domoticaImg,
    title: "Smart Penthouse",
    location: "Brussel",
    category: "Domotica",
    challenge: "Luxe penthouse met complex verlichtingsplan en de wens om alles via smartphone te bedienen.",
    approach: "KNX-domotica met Loxone Miniserver, 120 lichtpunten, automatische zonwering en klimaatregeling.",
    result: "Volledig geautomatiseerd penthouse met intuïtieve bediening en 30% energiebesparing.",
  },
  {
    img: groepenkastImg,
    title: "Renovatie Herenhuis",
    location: "Leuven",
    category: "Groepenkast",
    challenge: "Beschermd herenhuis met verouderde installatie uit de jaren '60. Keuring was afgekeurd.",
    approach: "Volledige herbekabeling met respect voor het historische karakter. Nieuwe groepenkast met 3-fasig.",
    result: "Installatie goedgekeurd bij eerste keuring. De woning is nu veilig en klaar voor de toekomst.",
  },
  {
    img: electricalImg,
    title: "Nieuwbouw KMO-loods",
    location: "Mechelen",
    category: "Elektrisch",
    challenge: "Nieuwe KMO-loods van 800m² met kantoren, magazijn en laaddock die volledig moest worden bekabeld.",
    approach: "Volledige elektrische installatie met led-verlichting, noodverlichting, branddetectie en data-bekabeling.",
    result: "Opgeleverd binnen 2 weken, goedgekeurd bij eerste keuring. Energiekosten 40% lager dan gemiddeld.",
  },
  {
    img: wiringImg,
    title: "Appartementenblok Duurzaam",
    location: "Antwerpen",
    category: "Elektrisch",
    challenge: "Renovatie van elektrische installatie in een blok van 12 appartementen zonder langdurige stroomonderbreking.",
    approach: "Gefaseerde aanpak per verdieping met tijdelijke voeding. Nieuwe groepenkast per unit.",
    result: "Alle 12 appartementen conform AREI in slechts 6 weken, met minimale hinder voor bewoners.",
  },
];

const Projecten = () => {
  const [filter, setFilter] = useState("Alle");
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);

  const filtered = filter === "Alle" ? projects : projects.filter((p) => p.category === filter);

  return (
    <main>
      <Navbar />

      <section className="pt-32 pb-16 bg-navy">
        <div className="container-max px-4 sm:px-6 lg:px-8">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
            <span className="text-electric text-sm font-semibold uppercase tracking-widest">Portfolio</span>
            <h1 className="text-4xl md:text-5xl font-heading font-bold text-primary-foreground mt-2">
              Onze <span className="text-gradient">realisaties</span>
            </h1>
            <p className="text-primary-foreground/60 mt-4 max-w-lg mx-auto">
              Ontdek een selectie van onze meest recente projecten door heel België.
            </p>
          </motion.div>
        </div>
      </section>

      <section className="section-padding bg-background">
        <div className="container-max">
          {/* Filters */}
          <div className="flex flex-wrap gap-2 justify-center mb-12">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  filter === cat
                    ? "bg-electric text-accent-foreground shadow-lg"
                    : "bg-secondary text-secondary-foreground hover:bg-electric/10 hover:text-electric"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* Grid */}
          <motion.div layout className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {filtered.map((p) => (
                <motion.div
                  key={p.title}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  className="group glass-card overflow-hidden hover-lift cursor-pointer"
                  onClick={() => setSelectedProject(p)}
                >
                  <div className="relative h-52 overflow-hidden">
                    <img src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    <div className="absolute inset-0 bg-gradient-to-t from-card/80 to-transparent" />
                    <div className="absolute bottom-4 left-4 flex gap-2">
                      <span className="text-xs px-3 py-1 rounded-full bg-electric text-accent-foreground font-semibold">{p.category}</span>
                      <span className="text-xs px-3 py-1 rounded-full bg-card/80 text-foreground flex items-center gap-1">
                        <MapPin className="w-3 h-3" /> {p.location}
                      </span>
                    </div>
                  </div>
                  <div className="p-5">
                    <h3 className="font-heading font-bold text-foreground mb-2">{p.title}</h3>
                    <p className="text-sm text-muted-foreground line-clamp-2">{p.challenge}</p>
                    <span className="inline-flex items-center text-sm font-semibold text-electric mt-3 gap-1.5 group-hover:gap-3 transition-all">
                      Bekijk details <ArrowRight className="w-4 h-4" />
                    </span>
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Project Detail Modal */}
      <AnimatePresence>
        {selectedProject && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-navy/80 backdrop-blur-sm flex items-center justify-center p-4"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={{ opacity: 0, y: 30, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.95 }}
              onClick={(e) => e.stopPropagation()}
              className="glass-card max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <img src={selectedProject.img} alt={selectedProject.title} className="w-full h-64 object-cover" />
              <div className="p-8">
                <div className="flex items-center gap-2 mb-4">
                  <span className="text-xs px-3 py-1 rounded-full bg-electric text-accent-foreground font-semibold">{selectedProject.category}</span>
                  <span className="text-xs text-muted-foreground flex items-center gap-1">
                    <MapPin className="w-3 h-3" /> {selectedProject.location}
                  </span>
                </div>
                <h2 className="text-2xl font-heading font-bold text-foreground mb-6">{selectedProject.title}</h2>

                <div className="space-y-4 mb-6">
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-electric mb-1">Uitdaging</h4>
                    <p className="text-sm text-muted-foreground">{selectedProject.challenge}</p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-electric mb-1">Aanpak</h4>
                    <p className="text-sm text-muted-foreground">{selectedProject.approach}</p>
                  </div>
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-electric mb-1">Resultaat</h4>
                    <p className="text-sm text-muted-foreground">{selectedProject.result}</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Link to="/contact">
                    <Button className="bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold hover:opacity-90 transition-opacity">
                      Soortgelijk project? <ArrowRight className="w-4 h-4 ml-2" />
                    </Button>
                  </Link>
                  <Button variant="outline" onClick={() => setSelectedProject(null)}>
                    Sluiten
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <CTASection />
      <Footer />
      <FloatingCTA />
    </main>
  );
};

export default Projecten;
