import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import IntroSection from "@/components/IntroSection";
import ServicesSection from "@/components/ServicesSection";
import WhyVoltix from "@/components/WhyVoltix";
import ProjectsSection from "@/components/ProjectsSection";
import ReviewsSection from "@/components/ReviewsSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";

const Index = () => (
  <main>
    <Navbar />
    <HeroSection />
    <IntroSection />
    <ServicesSection />
    <WhyVoltix />
    <ProjectsSection />
    <ReviewsSection />
    <CTASection />
    <Footer />
    <FloatingCTA />
  </main>
);

export default Index;
