import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ShieldCheck, Eye, Target, Heart, Lightbulb, Award, CheckCircle } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import FloatingCTA from "@/components/FloatingCTA";
import CTASection from "@/components/CTASection";
import teamImg from "@/assets/team-photo.jpg";
import wiringImg from "@/assets/wiring-closeup.jpg";

const values = [
  { icon: ShieldCheck, title: "Veiligheid", desc: "AREI-conforme installaties, altijd keuringsklaar opgeleverd. Veiligheid staat bij alles wat we doen centraal." },
  { icon: Eye, title: "Transparantie", desc: "Heldere offertes zonder verborgen kosten. U weet exact wat u betaalt vóór de eerste schroef wordt gedraaid." },
  { icon: Lightbulb, title: "Innovatie", desc: "We investeren continu in de nieuwste technologieën: van slimme domotica tot geavanceerde energieopslag." },
  { icon: Heart, title: "Klantgerichtheid", desc: "Persoonlijke service, flexibele planning en opvolging na oplevering. Uw tevredenheid is onze prioriteit." },
];

const certs = [
  "AREI gecertificeerd",
  "BA4/BA5 erkend",
  "VCA** gecertificeerd",
  "Synergrid erkend installateur",
  "Fluvius partner",
  "Tesla Certified Installer",
];

const OverOns = () => (
  <main>
    <Navbar />

    {/* Header */}
    <section className="pt-32 pb-16 bg-navy">
      <div className="container-max px-4 sm:px-6 lg:px-8">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <span className="text-electric text-sm font-semibold uppercase tracking-widest">Over Ons</span>
          <h1 className="text-4xl md:text-5xl font-heading font-bold text-primary-foreground mt-2">
            Het verhaal achter <span className="text-gradient">Voltix</span>
          </h1>
          <p className="text-primary-foreground/60 mt-4 max-w-lg mx-auto">
            Al meer dan 15 jaar de maatstaf in Belgische elektrotechniek.
          </p>
        </motion.div>
      </div>
    </section>

    {/* Story */}
    <section className="section-padding bg-background">
      <div className="container-max">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <h2 className="text-3xl font-heading font-bold text-foreground mb-6">
              Van passie voor techniek naar <span className="text-gradient">marktleider</span>
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Voltix Electro Solutions werd opgericht in 2009 door een team van ervaren elektriciens
                met een gemeenschappelijke droom: de standaard in Belgische elektrotechniek naar een hoger
                niveau tillen. Wat begon als een klein installatiebedrijf in Antwerpen, is uitgegroeid tot
                een van de meest gerespecteerde namen in de sector.
              </p>
              <p>
                Met meer dan 500 succesvol afgeronde projecten — van luxe villa's tot grote
                commerciële panden — hebben we bewezen dat kwaliteit, veiligheid en innovatie
                hand in hand gaan. Ons team van 25+ gecertificeerde vakmensen staat dagelijks
                klaar om uw elektrische installatie naar het hoogste niveau te brengen.
              </p>
              <p>
                Vandaag zijn we actief in heel België en staan we bekend om onze snelle service,
                transparante communicatie en 24/7 beschikbaarheid bij storingen.
              </p>
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <img src={wiringImg} alt="Professionele bedrading" className="rounded-xl shadow-2xl w-full" />
          </motion.div>
        </div>
      </div>
    </section>

    {/* Mission & Vision */}
    <section className="section-padding bg-surface-warm">
      <div className="container-max">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="glass-card p-8">
            <div className="w-12 h-12 rounded-xl bg-electric/10 flex items-center justify-center mb-4">
              <Target className="w-6 h-6 text-electric" />
            </div>
            <h3 className="text-xl font-heading font-bold text-foreground mb-3">Onze Missie</h3>
            <p className="text-muted-foreground leading-relaxed">
              Elke Belgische woning en elk bedrijf voorzien van veilige, duurzame en
              toekomstbestendige elektrische installaties. We streven naar uitmuntendheid
              in elke kabel die we trekken en elke verbinding die we maken.
            </p>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="glass-card p-8">
            <div className="w-12 h-12 rounded-xl bg-electric/10 flex items-center justify-center mb-4">
              <Eye className="w-6 h-6 text-electric" />
            </div>
            <h3 className="text-xl font-heading font-bold text-foreground mb-3">Onze Visie</h3>
            <p className="text-muted-foreground leading-relaxed">
              Een wereld waarin elk gebouw slim, veilig en energiezuinig is. We geloven
              dat de toekomst elektrisch is en dat vakmanschap het verschil maakt. Voltix
              wil de brug zijn tussen technologie en de mens.
            </p>
          </motion.div>
        </div>
      </div>
    </section>

    {/* Values */}
    <section className="section-padding bg-background">
      <div className="container-max">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-16">
          <span className="text-electric text-sm font-semibold uppercase tracking-widest">Kernwaarden</span>
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2">
            Waar we voor <span className="text-gradient">staan</span>
          </h2>
        </motion.div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {values.map((v, i) => (
            <motion.div
              key={v.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-6 text-center hover-lift"
            >
              <div className="w-14 h-14 rounded-xl bg-electric/10 flex items-center justify-center mx-auto mb-4">
                <v.icon className="w-7 h-7 text-electric" />
              </div>
              <h3 className="font-heading font-bold text-foreground mb-2">{v.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    {/* Team */}
    <section className="section-padding bg-surface-warm">
      <div className="container-max">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <img src={teamImg} alt="Team Voltix" className="rounded-xl shadow-2xl w-full" />
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }}>
            <span className="text-electric text-sm font-semibold uppercase tracking-widest">Ons Team</span>
            <h2 className="text-3xl font-heading font-bold text-foreground mt-2 mb-6">
              25+ gecertificeerde <span className="text-gradient">vakmensen</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              Ons team bestaat uit ervaren elektriciens, projectleiders en adviseurs die
              allemaal één ding gemeen hebben: een passie voor vakmanschap. Elke medewerker
              is BA4/BA5 gecertificeerd en volgt jaarlijks bijscholing om op de hoogte te
              blijven van de nieuwste technieken en regelgeving.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Van de eerste offerte tot de oplevering en nazorg: bij Voltix staat persoonlijk
              contact centraal. U heeft altijd een vast aanspreekpunt dat uw project van A tot Z begeleidt.
            </p>
          </motion.div>
        </div>
      </div>
    </section>

    {/* Certificates */}
    <section className="section-padding bg-background">
      <div className="container-max">
        <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-center mb-12">
          <span className="text-electric text-sm font-semibold uppercase tracking-widest">Certificaten</span>
          <h2 className="text-3xl font-heading font-bold text-foreground mt-2">
            Erkend en <span className="text-gradient">gecertificeerd</span>
          </h2>
        </motion.div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {certs.map((c, i) => (
            <motion.div
              key={c}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className="glass-card p-4 text-center hover-lift"
            >
              <Award className="w-8 h-8 text-electric mx-auto mb-2" />
              <span className="text-xs font-semibold text-foreground">{c}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <CTASection />
    <Footer />
    <FloatingCTA />
  </main>
);

export default OverOns;
