import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";

const CTASection = () => (
  <section className="relative py-24 overflow-hidden">
    <div className="absolute inset-0 bg-gradient-to-br from-navy via-navy-light to-navy" />
    <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 30% 50%, hsl(210 100% 50% / 0.3) 0%, transparent 60%)" }} />

    <div className="relative container-max px-4 sm:px-6 lg:px-8 text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-heading font-bold text-primary-foreground mb-6 max-w-3xl mx-auto">
          Klaar voor een veilige en toekomstgerichte{" "}
          <span className="text-gradient">elektrische installatie?</span>
        </h2>
        <p className="text-primary-foreground/60 text-lg mb-10 max-w-xl mx-auto">
          Vraag vandaag nog uw gratis en vrijblijvende offerte aan. Wij nemen binnen 24 uur contact met u op.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link to="/contact">
            <Button size="lg" className="bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold text-base px-10 hover:opacity-90 transition-opacity shadow-xl electric-glow-shadow">
              Vraag Vandaag Nog Uw Offerte Aan
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
          <a href="tel:+32470123456">
            <Button size="lg" variant="outline" className="border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10 font-semibold text-base px-8">
              <Phone className="w-5 h-5 mr-2" />
              Bel Ons Direct
            </Button>
          </a>
        </div>
      </motion.div>
    </div>
  </section>
);

export default CTASection;
