import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Shield, Clock, Award, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImg from "@/assets/hero-electrician.jpg";

const stats = [
  { icon: Clock, label: "Jaar Ervaring", value: "15+" },
  { icon: Award, label: "Afgeronde Projecten", value: "500+" },
  { icon: Shield, label: "Gecertificeerde Techniekers", value: "100%" },
  { icon: Users, label: "Storingsdienst", value: "24/7" },
];

const HeroSection = () => (
  <section className="relative min-h-screen flex items-center overflow-hidden">
    {/* Background */}
    <div className="absolute inset-0">
      <img src={heroImg} alt="Voltix elektricien aan het werk" className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-r from-navy/95 via-navy/80 to-navy/40" />
      <div className="absolute inset-0 bg-gradient-to-t from-navy via-transparent to-transparent" />
    </div>

    <div className="relative container-max px-4 sm:px-6 lg:px-8 pt-32 pb-20">
      <div className="max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-electric/10 border border-electric/20 text-electric text-sm font-medium mb-6"
        >
          <span className="w-2 h-2 rounded-full bg-electric animate-pulse" />
          Gecertificeerd & Verzekerd
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl lg:text-6xl font-heading font-bold text-primary-foreground leading-tight mb-6"
        >
          Professionele{" "}
          <span className="text-gradient">Elektrotechniek</span>{" "}
          voor Woning & Bedrijf.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-lg text-primary-foreground/70 mb-8 max-w-lg"
        >
          Betrouwbare, veilige en duurzame elektrische oplossingen door gecertificeerde vakmensen. Actief in heel België met 24/7 service.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row gap-4"
        >
          <Link to="/contact">
            <Button size="lg" className="bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold text-base px-8 hover:opacity-90 transition-opacity shadow-xl electric-glow-shadow">
              Vraag een Offerte Aan
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
          <Link to="/diensten">
            <Button size="lg" variant="outline" className="border-primary-foreground/20 text-primary-foreground hover:bg-primary-foreground/10 font-semibold text-base px-8">
              Ontdek Onze Diensten
            </Button>
          </Link>
        </motion.div>
      </div>

      {/* Stats Bar */}
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="mt-20 grid grid-cols-2 lg:grid-cols-4 gap-4"
      >
        {stats.map((stat) => (
          <div
            key={stat.label}
            className="glass-card bg-navy-light/50 border-electric/10 p-5 text-center"
          >
            <stat.icon className="w-6 h-6 text-electric mx-auto mb-2" />
            <div className="text-2xl font-heading font-bold text-primary-foreground">{stat.value}</div>
            <div className="text-xs text-primary-foreground/50 uppercase tracking-wider">{stat.label}</div>
          </div>
        ))}
      </motion.div>
    </div>
  </section>
);

export default HeroSection;
