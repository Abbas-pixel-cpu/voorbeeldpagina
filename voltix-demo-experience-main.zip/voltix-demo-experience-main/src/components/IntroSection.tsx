import { motion } from "framer-motion";
import { Zap, ShieldCheck, MapPin, Users } from "lucide-react";
import companyVanImg from "@/assets/company-van.jpg";

const highlights = [
  { icon: Zap, text: "15+ jaar ervaring in elektrotechniek" },
  { icon: ShieldCheck, text: "Gecertificeerde BA4/BA5 techniekers" },
  { icon: MapPin, text: "Actief in heel België" },
  { icon: Users, text: "500+ tevreden klanten" },
];

const IntroSection = () => (
  <section className="section-padding bg-background">
    <div className="container-max">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <span className="text-electric text-sm font-semibold uppercase tracking-widest">Over Voltix</span>
          <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2 mb-6">
            Uw betrouwbare partner in{" "}
            <span className="text-gradient">elektrotechniek</span>
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-6">
            Voltix Electro Solutions is een gevestigd Belgisch elektrotechnisch installatiebedrijf
            met meer dan 15 jaar ervaring. Ons team van gecertificeerde vakmensen staat garant voor
            veilige, duurzame en kwalitatieve elektrische installaties — zowel voor particulieren,
            KMO's als projectontwikkelaars.
          </p>
          <p className="text-muted-foreground leading-relaxed mb-8">
            Van een nieuwe groepenkast tot een volledig geautomatiseerde woning: wij leveren altijd
            topkwaliteit, met transparante offertes en een snelle uitvoering.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {highlights.map((h) => (
              <div key={h.text} className="flex items-center gap-3">
                <div className="w-10 h-10 shrink-0 rounded-lg bg-electric/10 flex items-center justify-center">
                  <h.icon className="w-5 h-5 text-electric" />
                </div>
                <span className="text-sm font-medium text-foreground">{h.text}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          className="relative"
        >
          <img
            src={companyVanImg}
            alt="Voltix bedrijfswagen"
            className="rounded-xl shadow-2xl w-full"
          />
          <div className="absolute -bottom-6 -left-6 glass-card p-5 shadow-xl hidden md:block">
            <div className="text-3xl font-heading font-bold text-electric">500+</div>
            <div className="text-sm text-muted-foreground">Succesvolle projecten</div>
          </div>
        </motion.div>
      </div>
    </div>
  </section>
);

export default IntroSection;
