import { motion } from "framer-motion";
import { MapPin } from "lucide-react";
import solarImg from "@/assets/solar-panels.jpg";
import evImg from "@/assets/ev-charger.jpg";
import domoticaImg from "@/assets/domotica.jpg";
import groepenkastImg from "@/assets/groepenkast.jpg";

const projects = [
  {
    img: solarImg,
    title: "Villa Zonnekracht",
    location: "Antwerpen",
    type: "Zonnepanelen",
    desc: "22 premium zonnepanelen met batterijopslag voor volledige energie-onafhankelijkheid.",
  },
  {
    img: evImg,
    title: "Kantoorpark Laadplein",
    location: "Gent",
    type: "Laadpalen",
    desc: "8 slimme laadpalen voor een bedrijvenpark met load-balancing systeem.",
  },
  {
    img: domoticaImg,
    title: "Smart Penthouse",
    location: "Brussel",
    type: "Domotica",
    desc: "Volledig KNX-geautomatiseerd penthouse met verlichtings- en klimaatregeling.",
  },
  {
    img: groepenkastImg,
    title: "Renovatie Herenhuis",
    location: "Leuven",
    type: "Groepenkast",
    desc: "Volledige elektrische renovatie van een beschermd herenhuis met moderne normen.",
  },
];

const ProjectsSection = () => (
  <section className="section-padding bg-background">
    <div className="container-max">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-electric text-sm font-semibold uppercase tracking-widest">Realisaties</span>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2">
          Onze recente <span className="text-gradient">projecten</span>
        </h2>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {projects.map((p, i) => (
          <motion.div
            key={p.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="group glass-card overflow-hidden hover-lift"
          >
            <div className="relative h-56 overflow-hidden">
              <img src={p.img} alt={p.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-card/90 to-transparent" />
              <div className="absolute bottom-4 left-4 flex gap-2">
                <span className="text-xs px-3 py-1 rounded-full bg-electric text-accent-foreground font-semibold">{p.type}</span>
                <span className="text-xs px-3 py-1 rounded-full bg-card/80 text-foreground flex items-center gap-1">
                  <MapPin className="w-3 h-3" /> {p.location}
                </span>
              </div>
            </div>
            <div className="p-6">
              <h3 className="font-heading font-bold text-foreground text-lg mb-2">{p.title}</h3>
              <p className="text-sm text-muted-foreground">{p.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ProjectsSection;
