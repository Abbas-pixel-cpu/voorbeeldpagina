import { Link } from "react-router-dom";
import { MessageCircle } from "lucide-react";

const FloatingCTA = () => (
  <>
    {/* WhatsApp button */}
    <a
      href="https://wa.me/32470123456"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
      aria-label="WhatsApp"
    >
      <MessageCircle className="w-7 h-7 text-primary-foreground" fill="currentColor" />
    </a>

    {/* Mobile sticky CTA */}
    <div className="fixed bottom-0 left-0 right-0 z-30 lg:hidden bg-navy/95 backdrop-blur-md border-t border-electric/10 p-3 pr-24">
      <Link
        to="/contact"
        className="block w-full text-center py-3 rounded-lg bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold text-sm"
      >
        Gratis Offerte Aanvragen
      </Link>
    </div>
  </>
);

export default FloatingCTA;
