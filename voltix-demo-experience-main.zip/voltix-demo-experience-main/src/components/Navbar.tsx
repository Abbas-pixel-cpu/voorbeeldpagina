import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "Diensten", path: "/diensten" },
  { label: "Projecten", path: "/projecten" },
  { label: "Over Ons", path: "/over-ons" },
  { label: "Contact", path: "/contact" },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-navy/95 backdrop-blur-md shadow-lg py-3"
          : "bg-transparent py-5"
      }`}
    >
      <div className="container-max px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-electric to-electric-glow flex items-center justify-center group-hover:animate-pulse-glow transition-all">
            <Zap className="w-6 h-6 text-primary-foreground" fill="currentColor" />
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-heading font-bold text-primary-foreground leading-tight">
              Voltix
            </span>
            <span className="text-[10px] uppercase tracking-[0.2em] text-electric-glow leading-tight">
              Electro Solutions
            </span>
          </div>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden lg:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`text-sm font-medium transition-colors relative after:absolute after:bottom-[-4px] after:left-0 after:w-full after:h-[2px] after:bg-electric after:origin-left after:transition-transform after:duration-300 ${
                location.pathname === link.path
                  ? "text-electric after:scale-x-100"
                  : "text-primary-foreground/80 hover:text-primary-foreground after:scale-x-0 hover:after:scale-x-100"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </div>

        {/* Desktop CTA */}
        <div className="hidden lg:flex items-center gap-4">
          <a
            href="tel:+32470123456"
            className="flex items-center gap-2 text-sm text-primary-foreground/80 hover:text-electric transition-colors"
          >
            <Phone className="w-4 h-4" />
            <span>+32 470 12 34 56</span>
          </a>
          <Link to="/contact">
            <Button className="bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold hover:opacity-90 transition-opacity shadow-lg">
              Gratis Offerte
            </Button>
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="lg:hidden text-primary-foreground p-2"
          aria-label="Menu"
        >
          {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-navy/98 backdrop-blur-md border-t border-electric/10 animate-fade-up">
          <div className="container-max px-4 py-6 space-y-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`block text-base font-medium py-2 ${
                  location.pathname === link.path
                    ? "text-electric"
                    : "text-primary-foreground/80"
                }`}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-4 border-t border-electric/10 space-y-3">
              <a
                href="tel:+32470123456"
                className="flex items-center gap-2 text-sm text-primary-foreground/80"
              >
                <Phone className="w-4 h-4" />
                +32 470 12 34 56
              </a>
              <Link to="/contact" className="block">
                <Button className="w-full bg-gradient-to-r from-electric to-electric-glow text-accent-foreground font-semibold">
                  Gratis Offerte
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
