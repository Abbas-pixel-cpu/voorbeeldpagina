import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const reviews = [
  { name: "Peter V.", stars: 5, text: "Uitstekende service! Groepenkast volledig vernieuwd in één dag. Professioneel team en nette oplevering." },
  { name: "Sarah D.", stars: 5, text: "Zonnepanelen geïnstalleerd door Voltix. Alles perfect geregeld, van advies tot plaatsing en keuring. Aanrader!" },
  { name: "Marc L.", stars: 5, text: "Laadpaal thuis laten plaatsen. Snelle planning, correcte prijs en vakkundig geïnstalleerd. Top!" },
  { name: "Katrien B.", stars: 5, text: "Domotica in onze nieuwbouw. Het team van Voltix dacht proactief mee en leverde een geweldig resultaat." },
];

const ReviewsSection = () => (
  <section className="section-padding bg-surface-warm">
    <div className="container-max">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-electric text-sm font-semibold uppercase tracking-widest">Klantreviews</span>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2">
          Wat onze klanten <span className="text-gradient">zeggen</span>
        </h2>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reviews.map((r, i) => (
          <motion.div
            key={r.name}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="glass-card p-6 hover-lift relative"
          >
            <Quote className="w-8 h-8 text-electric/20 absolute top-4 right-4" />
            <div className="flex gap-0.5 mb-4">
              {Array.from({ length: r.stars }).map((_, j) => (
                <Star key={j} className="w-4 h-4 text-electric fill-electric" />
              ))}
            </div>
            <p className="text-sm text-foreground mb-4 italic leading-relaxed">"{r.text}"</p>
            <div className="text-sm font-heading font-semibold text-foreground">{r.name}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ReviewsSection;
