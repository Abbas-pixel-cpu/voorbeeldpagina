import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Zap, Sun, Car, Cpu, Settings, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import electricalImg from "@/assets/electrical-install.jpg";
import solarImg from "@/assets/solar-panels.jpg";
import evImg from "@/assets/ev-charger.jpg";
import domoticaImg from "@/assets/domotica.jpg";
import groepenkastImg from "@/assets/groepenkast.jpg";

const services = [
  {
    icon: Zap,
    title: "Elektrische Installaties",
    desc: "Volledige nieuwbouw- en renovatie-installaties volgens de strengste veiligheidsnormen.",
    img: electricalImg,
    benefits: ["AREI-conform", "Keuringsklaar", "Garantie op werk"],
  },
  {
    icon: Sun,
    title: "Zonnepanelen",
    desc: "Maximaal rendement met premium zonnepanelen. Bespaar tot 70% op uw energiekosten.",
    img: solarImg,
    benefits: ["Premium panelen", "Monitoring app", "Terugverdientijd berekening"],
  },
  {
    icon: Car,
    title: "Laadpalen",
    desc: "Thuis of op kantoor: wij installeren slimme laadoplossingen voor elke situatie.",
    img: evImg,
    benefits: ["Alle merken", "Slim laden", "Subsidie-advies"],
  },
  {
    icon: Cpu,
    title: "Domotica",
    desc: "Maak uw woning slim. Verlichting, verwarming en beveiliging in één systeem.",
    img: domoticaImg,
    benefits: ["KNX & Loxone", "Op maat", "Toekomstbestendig"],
  },
  {
    icon: Settings,
    title: "Groepenkast Renovaties",
    desc: "Verouderde groepenkast? Wij upgraden naar de nieuwste veiligheidsnormen.",
    img: groepenkastImg,
    benefits: ["Veiliger wonen", "Norm-conform", "Snelle uitvoering"],
  },
  {
    icon: Phone,
    title: "24/7 Storingsdienst",
    desc: "Elektrisch noodgeval? Ons team staat dag en nacht voor u klaar.",
    img: electricalImg,
    benefits: ["Snelle respons", "Heel Vlaanderen", "Transparante tarieven"],
  },
];

const ServicesSection = () => (
  <section className="section-padding bg-background">
    <div className="container-max">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-electric text-sm font-semibold uppercase tracking-widest">Onze Diensten</span>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2">
          Alles voor uw <span className="text-gradient">elektrische installatie</span>
        </h2>
        <p className="text-muted-foreground mt-4 max-w-xl mx-auto">
          Van nieuwbouw tot renovatie, van zonnepanelen tot domotica — wij bieden de complete oplossing.
        </p>
      </motion.div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {services.map((service, i) => (
          <motion.div
            key={service.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1 }}
            className="group glass-card overflow-hidden hover-lift"
          >
            <div className="relative h-48 overflow-hidden">
              <img
                src={service.img}
                alt={service.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-card via-transparent to-transparent" />
              <div className="absolute top-4 left-4 w-10 h-10 rounded-lg bg-electric flex items-center justify-center">
                <service.icon className="w-5 h-5 text-accent-foreground" />
              </div>
            </div>
            <div className="p-6">
              <h3 className="text-lg font-heading font-bold text-foreground mb-2">{service.title}</h3>
              <p className="text-sm text-muted-foreground mb-4">{service.desc}</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {service.benefits.map((b) => (
                  <span key={b} className="text-xs px-2.5 py-1 rounded-full bg-electric/10 text-electric font-medium">
                    {b}
                  </span>
                ))}
              </div>
              <Link to="/contact" className="inline-flex items-center text-sm font-semibold text-electric hover:gap-3 gap-1.5 transition-all">
                Meer info <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesSection;
