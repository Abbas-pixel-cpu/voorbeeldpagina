import { motion } from "framer-motion";
import { FileText, CalendarCheck, ShieldCheck, BadgeCheck, HeartPulse } from "lucide-react";

const reasons = [
  { icon: FileText, title: "Transparante Offertes", desc: "Geen verborgen kosten. U weet exact wat u betaalt vóór de start." },
  { icon: CalendarCheck, title: "Snelle Planning", desc: "Korte wachttijden en flexibele inplanning rond uw agenda." },
  { icon: ShieldCheck, title: "10 Jaar Garantie", desc: "Tot 10 jaar garantie op materiaal en installatie." },
  { icon: BadgeCheck, title: "Gecertificeerde Installateurs", desc: "Elk teamlid is BA4/BA5 gecertificeerd en voortdurend bijgeschoold." },
  { icon: HeartPulse, title: "Veiligheid als Prioriteit", desc: "AREI-conforme installaties, altijd keuringsklaar opgeleverd." },
];

const WhyVoltix = () => (
  <section className="section-padding bg-surface-warm">
    <div className="container-max">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="text-center mb-16"
      >
        <span className="text-electric text-sm font-semibold uppercase tracking-widest">Waarom Voltix</span>
        <h2 className="text-3xl md:text-4xl font-heading font-bold text-foreground mt-2">
          Uw installatie in <span className="text-gradient">vertrouwde handen</span>
        </h2>
      </motion.div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
        {reasons.map((r, i) => (
          <motion.div
            key={r.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08 }}
            className="glass-card p-6 text-center hover-lift"
          >
            <div className="w-12 h-12 rounded-xl bg-electric/10 flex items-center justify-center mx-auto mb-4">
              <r.icon className="w-6 h-6 text-electric" />
            </div>
            <h3 className="font-heading font-semibold text-foreground mb-2 text-sm">{r.title}</h3>
            <p className="text-xs text-muted-foreground leading-relaxed">{r.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default WhyVoltix;
