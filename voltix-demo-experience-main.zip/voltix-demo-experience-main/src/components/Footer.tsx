import { Link } from "react-router-dom";
import { Zap, Phone, Mail, MapPin, Clock, Facebook, Instagram, Linkedin } from "lucide-react";

const Footer = () => (
  <footer className="bg-navy text-primary-foreground">
    <div className="container-max section-padding pb-8">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
        {/* Brand */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-electric to-electric-glow flex items-center justify-center">
              <Zap className="w-6 h-6 text-primary-foreground" fill="currentColor" />
            </div>
            <div>
              <div className="font-heading font-bold text-lg leading-tight">Voltix</div>
              <div className="text-[10px] uppercase tracking-[0.2em] text-electric-glow">Electro Solutions</div>
            </div>
          </div>
          <p className="text-primary-foreground/60 text-sm leading-relaxed mb-4">
            Uw betrouwbare partner voor veilige en duurzame elektrische installaties in heel België.
          </p>
          <p className="text-primary-foreground/40 text-xs mb-4">
            BTW: BE 0123.456.789 (fictief)
          </p>
          <div className="flex gap-3">
            {[Facebook, Instagram, Linkedin].map((Icon, i) => (
              <a key={i} href="#" className="w-9 h-9 rounded-lg bg-navy-light flex items-center justify-center hover:bg-electric transition-colors">
                <Icon className="w-4 h-4" />
              </a>
            ))}
          </div>
        </div>

        {/* Diensten */}
        <div>
          <h4 className="font-heading text-sm font-semibold uppercase tracking-wider text-electric mb-4">Diensten</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/60">
            {["Elektrische Installaties", "Zonnepanelen", "Laadpalen", "Domotica", "Groepenkast Renovaties", "24/7 Storingsdienst"].map((s) => (
              <li key={s}><Link to="/diensten" className="hover:text-electric transition-colors">{s}</Link></li>
            ))}
          </ul>
        </div>

        {/* Contact */}
        <div>
          <h4 className="font-heading text-sm font-semibold uppercase tracking-wider text-electric mb-4">Contact</h4>
          <ul className="space-y-3 text-sm text-primary-foreground/60">
            <li className="flex gap-2"><Phone className="w-4 h-4 mt-0.5 text-electric" /> +32 470 12 34 56</li>
            <li className="flex gap-2"><Mail className="w-4 h-4 mt-0.5 text-electric" /> info@voltix.be</li>
            <li className="flex gap-2"><MapPin className="w-4 h-4 mt-0.5 text-electric" /> Industrieweg 42, 2000 Antwerpen</li>
            <li className="flex gap-2"><Clock className="w-4 h-4 mt-0.5 text-electric" /> Ma-Vr: 8:00 – 18:00</li>
          </ul>
        </div>

        {/* Werkgebied */}
        <div>
          <h4 className="font-heading text-sm font-semibold uppercase tracking-wider text-electric mb-4">Werkgebied</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/60">
            {["Antwerpen", "Gent", "Brussel", "Leuven", "Mechelen", "Heel België"].map((s) => (
              <li key={s}>{s}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="border-t border-primary-foreground/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-primary-foreground/40">
        <p>© 2025 Voltix Electro Solutions. Alle rechten voorbehouden. Dit is een demo website.</p>
        <div className="flex gap-6">
          <Link to="/privacy" className="hover:text-electric transition-colors">Privacybeleid</Link>
          <Link to="/voorwaarden" className="hover:text-electric transition-colors">Algemene Voorwaarden</Link>
          <Link to="/cookies" className="hover:text-electric transition-colors">Cookiebeleid</Link>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
